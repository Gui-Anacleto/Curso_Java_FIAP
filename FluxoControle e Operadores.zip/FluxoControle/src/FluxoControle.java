
public class FluxoControle {

	public static void main(String[] args) {
		int idade = 15;

	}

}
