package com.java.operadores;

public class OperadoresLogicos {
	public static void main(String[] args) {
		//and &&
		int idade = 20;
		
		boolean precisaVotar = idade >= 18 && idade < 70;
		System.out.println(precisaVotar);
		
		//or ||
		int nrAmarelo = 2, nrVermelho = 1;
		
		boolean suspenso = nrAmarelo == 1 || nrVermelho == 0;
		System.out.println(suspenso);
		
		//xor ^
		int x = 9, y = 11;
		
		boolean teste = x > 10 ^ y >10;
		System.out.println(teste);

		//not !
		boolean maiorIdade = !(idade >=18);
		System.out.println(maiorIdade);

}
}