package com.fiap.starts;

//import java.util.Arrays;

public class LengthStartsEnds {

	public static void main(String[] args) {
		String descricao = new String("Maça Gala, a maça mais doce do mercado!");
		
		/*
		//conta quantos caracteres
		System.out.println(descricao.length());
		//começa com
		System.out.println(descricao.startsWith("Maça"));
		//termina com
		System.out.println(descricao.endsWith("!"));
		
		
		//exibe o caracter na posição 1
		System.out.println(descricao.charAt(1));
		
		// retorna index da posicao do caracter G
		System.out.println(descricao.indexOf("G"));
		// retorna index da posicao do caracter Gala
		System.out.println(descricao.indexOf("Gala"));
		
		// retorna index da posicao do caracter a
		System.out.println(descricao.indexOf("a"));
		// retorna index da ultima ocorrencia do caracter a
		System.out.println(descricao.lastIndexOf("a"));
		
		
		//quebrar string
		//trocar todos os G por g
		System.out.println(descricao.replace("G","g"));
		//trocar todos os Gala por Fuji
		System.out.println(descricao.replace("Gala", "Fuji"));
		//trocar todos os a por A
		System.out.println(descricao.replace("a", "A"));
		
		//quebrar as strings sendo delimitado pelo espaço e contato pelo length.
		System.out.println(descricao.split(" ").length);
		// retorna index da ultima ocorrencia do caracter a
		System.out.println(Arrays.toString(descricao.split(" ")));
		
		*/
		
		//UpperCase e LowerCase
		//troca todos os caracteres por LowerCase
		System.out.println(descricao.toLowerCase());
		//troca todos os caracteres por UpperCase
		System.out.println(descricao.toUpperCase());
		//retorna index 0 ao 4
		System.out.println(descricao.substring(0,4));
		//do index 4 até o final
		System.out.println(descricao.substring(4));
		
		System.out.println(descricao.substring(
				descricao.indexOf("Maça"),
				descricao.indexOf(" ")));
		
		System.out.println(descricao);
	}

}
