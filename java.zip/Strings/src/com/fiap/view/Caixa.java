package com.fiap.view;

public class Caixa {

	public static void main(String[] args) {
		/*
		String nome;
		nome = new String();
		System.out.println(nome);
		
		String nome2= new String("Maça");
		System.out.println(nome2);
		
		
		//um pull - tipo cache
		String nome3= "Maça";
		System.out.println(nome3);
		
		
		String nome4=null;
		System.out.println(nome4.length());
		
		
		//scapes
		//quebra linha \n
		String descricao = "tpo Gala \nA maça mais doce do mercado";
		System.out.println(descricao);
		
		//espaçamento \t
		descricao = "Tipo Gala \tA maça mais doce do mercado";
		System.out.println(descricao);
		
		//usar " \"
		descricao = "tpo Gala: \"A maça mais doce do mercado\"";
		System.out.println(descricao);
		*/
		
		String nome = new String("Maça");
		String descricao = new String();
		descricao = "tipo Gala, a maça mais doce do mercado";
		
		String propaganda = nome + " " + descricao;
		System.out.println(propaganda);
		
		propaganda = nome.concat(" ").concat(descricao);
		System.out.println(propaganda);
		
		propaganda += "!";
		System.out.println(propaganda);
		
	}

}
