module Strings {
}