package br.com.fiap.banco;

import java.io.Serializable;

// implementar o Serializable, para que as informações dessa classe trafeguem em bytes.
public class Pessoa implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//JavaBeans - Encapsulamento
	// Precisa de um construtor padrão e estar com os atribultos estejam encapsulados.
	
	private String nome; // Protegido, nenhuma classe pode alterar, apenas os metodos.
	
	
	//gerar getters e setters.
	//Obter
	public String getNome() {
		return nome;
	}
	//Alterar
	public void setNome(String nome) {
		this.nome = nome;
	}
}
