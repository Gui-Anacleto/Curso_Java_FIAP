package br.com.fiap.banco;

import java.io.Serializable;

public class Conta implements Serializable{
	/**
	 *Especificação JAVABEANS define diretrizes que ditam os nomes de suas variaveis, os nomes
	 *e tipos de retorno de sus métodos e alguns outros aspectos para que o objeto, chamado de beans
	 *seja reutilizável.
	 *
	 * Regras para que uma classe sejá JAVABEANS:
	 * 
	 * -Ter um construtor padrão, sem algumentos.
	 * -Encapsular os seus atributos, provendo métodos para o acesso a eles em outras classes.
	 * -É uma boa prática implemntar a interface java.io.Serializable.
	 * 
	 * O encapsulamento é aplicado a métodos e atributos de uma classe e consiste em proteger
	 * os dados ou até mesmo escondê-los
	 * 
	 * O uso de métodos de leitura(ge) e escrita (set) visam desacoplar os atributos de uma classe dos 
	 * clientes que a utilizam.
	 */
	private static final long serialVersionUID = 1L;
	
	private int agencia;
	private int numero;
	private double saldo;
	
	public int getAgencia() {
		return agencia;
	}


	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}


	public int getNumero() {
		return numero;
	}


	public void setNumero(int numero) {
		this.numero = numero;
	}

	/*Construtor*/
	public Conta() {
		
	}
	
	
	public Conta(int agencia, int numero, double saldo) {
		this.agencia = agencia;
		this.numero=numero;
		this.saldo=saldo;
	}

	/*metodos*/
	public void depositar(double valor) {
		this.saldo += valor;
		/*this.saldo = this.saldo + valor;*/
	}
	
	public void retirar(double valor) {
		this.saldo -= valor;
	}
	
	public double getSaldo() {
		return this.saldo;
	}
}
