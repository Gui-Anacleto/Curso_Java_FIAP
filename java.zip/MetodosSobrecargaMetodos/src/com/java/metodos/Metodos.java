package com.java.metodos;

public class Metodos {
	public static void main(String[] args) {
		/*public class Conta{
			double saldo;
			
			public void retirar(double valor){
				saldo = saldo - valor;
				
			}
			
			public void retirar(double valor, double taxa) {
				saldo = saldo - valor - taxa;
			}*/
	}
}

