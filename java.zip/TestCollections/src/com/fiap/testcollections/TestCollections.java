package com.fiap.testcollections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TestCollections {
	public static void main(String[] args) {
		/*
		ArrayList carrinho = new ArrayList();
		Double valor = 100.55;
		int valor2 = 1;
		int valor3;
		
		carrinho.add(valor);
		carrinho.add("Uva");
		carrinho.add(valor2);
		
		System.out.println(carrinho.get(1));
		valor3 = (int) carrinho.get(2);
		
		System.out.println(valor3);
		
		*/
		
		//Interface List e uso de Generics
		//Generics não permite tipos primitivos
		
		//arraylist de strings(apenas elementos strings)
		List<String> carrinho = new ArrayList<String>();
		
		//isEmpty nos retorna true or false caso o array esta vazio ou não
		//System.out.println(carrinho.isEmpty());
		
		carrinho.add("Maça");
		carrinho.add("Morango");
		carrinho.add("Maça");
		//carrinho.set(1, "Pera");
		
		//size retorna o tamanho do array
		//System.out.println(carrinho.isEmpty());
		//System.out.println(carrinho.size());
		
		/*
		//contains retorna se a palavra Maça consta no array
		System.out.println(carrinho.contains("Maça"));
		
		//retorna posição da palavra Maça
		System.out.println(carrinho.indexOf("Maça"));
		
		//busca maça a partir da posição passada pelo indexOf
		System.out.println(carrinho.get(carrinho.indexOf("Maça")));
		
		//retorna qual a ultima ocorrencia da palavra Maça dentro do arraylist
		System.out.println(carrinho.lastIndexOf("Maça"));
		
		carrinho.remove(carrinho.indexOf("Maça"));
		System.out.println(carrinho.get(0));
		
		carrinho.clear();
		System.out.println(carrinho.isEmpty());
		
		
		 * add - Adiciona um objeto no set
		 * clear - removo todos os objetos do set
		 * contains - verifica se o objeto possui um objeto determinado
		 * isEmpity - verifica se o set está vazio
		 * remove - remove um objeto do set
		 * size - retorna a quantidade de objetos no set
		 * toArray - retorna uma array contendo os objetos do set
		 * 
		
		Set <String>  cesta = new HashSet<String>();
		System.out.println(cesta.isEmpty());
		cesta.add("Maça");
		cesta.add("Maça");
		cesta.add("maça");
		System.out.println(cesta.isEmpty());
		
		System.out.println(cesta.size());
		System.out.println(cesta);
		*/
		
		Map<String, String> caixa = new HashMap<String, String>();
		caixa.put("M225")
	}
}
