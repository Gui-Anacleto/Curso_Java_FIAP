package com.fiap.testexception;

public class TestException {

	public static void main(String[] args) {
		/*
		try {
			//trecho onde a exceção pode ocorrer
			int val = 10/0;
			System.out.println(val);
			
		} catch (Exception e) { // captura da exceção
			
			// tratamento da exceção
			e.printStackTrace();
		}
		try {
			int val = 10 / 0;
			int [] valores = new int[3];
			//indice que não existe no array
			System.out.println(valores[4]);
			
			String nome = null;
			//passar o length para uma variavel que não foi inicializada.
			System.out.println(nome.length());
			
			//converter string para int
			int numero = Integer.parseInt("zero");
		
			//erro aritmetico
		} catch (ArithmeticException e ) {
			System.out.println("Não é possivel realizar uma divisão por zero");
			
			//mensagem com a lista de erros
			System.out.println(e.getMessage());
			
			//imprime a pilha de erro da execeção
			e.printStackTrace();
			
			//erro de acesso indevido a algum indice
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Não é possivel acessar a posição 4 do array !");
		
		} catch (NullPointerException e) {
			System.out.println("Não foi possivel retornar o lenght, variavel nome não instanciada !");
			
		} catch (NumberFormatException e) {
			System.out.println("Não foi possivel realizar a conversão");
			
		} catch (Exception e) {
			System.out.println("Erro na execução do programa!");
		}*/
		
		
		//Throws
		FileWriter = 
		
	}

}
