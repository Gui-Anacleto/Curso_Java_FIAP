package com.java.construtor;

public class Construtor {

}
