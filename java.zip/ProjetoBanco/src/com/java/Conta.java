package com.java;

public class Conta {
	int numero;
	double saldo;
	
	Cliente cliente = new Cliente();
}
