package com.java;

public class Cliente {
	String nome;
	byte idade;
	
}
