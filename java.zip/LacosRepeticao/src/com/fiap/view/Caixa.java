package com.fiap.view;

import com.fiap.entity.Produto;

public class Caixa {
	
	public static void main(String[] args) {
		//int qtdProduto = 5;
		//int registro = 0;
		
		
		// while
		
		/*	while (registro < qtdProduto) {
			registro++;
			System.out.println("O produto numero "+ registro +" foi registrado");
		}*/
		
		
		// do while
		
	/*	do {
			registro++;
			System.out.println("O produto numero "+ registro +" foi registrado");	
		}	
		while (registro < qtdProduto); */
		
		/*
		// for
		for (int i=1; i <= qtdProduto; i++) {
			System.out.println("O caixa registou o produto " +i);
		}
		*/
		
		
		// Arrays
		/*
		float[] valores = new float[5];
		
		valores[0] = 10;
		valores[1] = 20;
		valores[2] = 30;
		valores[3] = 40;
		valores[4] = 50;
		
		System.out.println(valores[1]);
		
		
		float[] valores = {10,20,30,40,50};
		float[] valores2 = new float[] {10,20,30,40,50};
		
		System.out.println(valores[4]);
		System.out.println(valores2[4]);
		*/
		
		Produto[] produtos = new Produto[2];
		
		Produto prod1 = new Produto();
		prod1.setNome("Limão");
		prod1.setDescricao("Galego");
		prod1.setValor(4);
		
		Produto prod2 = new Produto();
		prod2.setNome("Maça");
		prod2.setDescricao("Gala");
		prod2.setValor(5);
		
		produtos[0] = prod1;
		produtos[1] = prod2;
		
		/*
		for(int i = 0; i < produtos.length; i++) {
			System.out.println(produtos[i].toString());
		
		
		for(Produto prod: produtos) {
			System.out.println(prod.toString());
		}}*/
		
		//10 correfores com três prateleiras cada
		Produto[][] localizaoProduto = new Produto[10][3];
		
		localizaoProduto[2][1] = prod1;
		localizaoProduto[2][2] = prod2;
		
		System.out.println(localizaoProduto[2][1].getNome());
		
	}
}
