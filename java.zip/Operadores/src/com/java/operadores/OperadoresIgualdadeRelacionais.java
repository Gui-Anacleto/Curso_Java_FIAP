package com.java.operadores;

public class OperadoresIgualdadeRelacionais {
	public static void main(String[] args) {
		
		int idade = 15;
		boolean maioridade = idade > 18;
		System.out.println(maioridade);
		
		boolean maiorigualidade = idade > 18;
		System.out.println(maiorigualidade);
		
		boolean igualidade = idade == 18;
		System.out.println(igualidade);
		
		boolean menoridade = idade < 18;
		System.out.println(menoridade);
		
		boolean menorigualidade = idade > 18;
		System.out.println(menorigualidade);
		
		boolean diferenteidade = idade != 18;
		System.out.println(diferenteidade);
		
}
}
